# Modbus Blockly Library for MicroPython (ESP32)

Thư viện Blockly hỗ trợ các khối lệnh lập trình cảm biến Modbus RS485 (các loại cảm biến như soil sensor, nhiệt độ, độ ẩm...) trên ESP32.

## Tính năng

- Khởi tạo UART/Modbus
- Đọc input register
- Đọc holding register
- Ghi holding register


